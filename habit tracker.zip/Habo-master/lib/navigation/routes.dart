class Routes {
  static String splashPath = '/splash';
  static String habitsPath = '/';
  static String statisticsPath = '/statistics';
  static String settingsPath = '/settings';
  static String onboardingPath = '/onboarding';
  static String createHabitPath = '/createHabit';
  static String editHabitPath = '/editHabit';
}
